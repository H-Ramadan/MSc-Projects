import Data.Maybe
import Data.List

--To run the code run the following command in terminal $ghci task1.hs
--to start the nlcc function while on; *Main>nlcc <[[ARRAY INPUT]]> <SEARCH NUMBER> 
-- for example *Main>nlcc <[[0,0,1],[0,0,0]]> 0
-- sets value of (x,y)
-- although it's not safe to use !! , however, a safety check is both done withing the fucntion and on the input it recives
setValue ::(Int,Int) -> Int -> [[Int]] -> [[Int]]
setValue (x,y) value matrix | x >= boundaryX || y >= boundaryY = matrix
                            |otherwise =take y matrix ++ [take x line ++ [value] ++ drop (x+1) line] ++ drop (y+1) matrix
                       where boundaryX = length (head matrix)
                             boundaryY = length matrix
                             line = matrix !! y
--checks if element in tuple has equivleant 
--https://stackoverflow.com/questions/53526615/searching-a-tuple-for-a-matching-pair
findTup :: [(Int,Int)] -> Int -> Maybe Int
findTup = flip lookup
--finds the true equivleant of a equivlency tuple based on an equivlency List
replaceEquivlent :: [(Int,Int)] -> (Int,Int) -> (Int,Int)
replaceEquivlent eList (val, equivalent) = case findTup eList equivalent of Just x -> replaceEquivlent eList (val, x)
                                                                            Nothing -> (val,equivalent)
--maps each element of the qeuvilency list to it's true equivleant 
--example [(3,2),(4,3),(5,4)] -> [(3,2),(4,2),(5,2)]
cleanElist ::  [(Int,Int)]-> [(Int,Int)]
cleanElist eList = map (\(x,y) -> replaceEquivlent eList (x,y)) eList
--counts uniqe labels and in the labled matrix and returns the highest connected compoenent 
--doesnt need to know the target search int as it only looks for labels > 1 and the labeling starts from 2
--this was an approach to possibly save time and keep the code nicer
count :: [Int] -> Int
count finalList = maximum (map snd cleanList)
                 where cleanList = map (\xs -> (head xs, length xs)) $ group $ sort (filter (> 1) finalList)
--returns an element at (x,y) in matrix
--checks for outofbounds and returns -1 if out of bounds
getElement2D :: [[Int]] -> (Int, Int) -> Int
getElement2D matrix (x, y) = if (x <= boundaryX && x > -1) &&  (y <= boundaryY && y > -1) then (matrix !! y) !! x else -1
                             where boundaryX = length (head matrix) - 1 --bound checks
                                   boundaryY = length matrix - 1

--retruns the left and up elements of an (x,y) position
findLeftandUp :: [[Int]] -> (Int, Int) -> [Int]
findLeftandUp matrix (x,y) = [getElement2D matrix (x - 1, y), getElement2D matrix(x, y - 1)]

--checks if a value is not a background or outofbounds
checkIfValid :: Int->Int -> Bool
checkIfValid val background = not (val == background || val == -1)

--input: matrix, (x,y), background and equvilency list
--output: a boolean to indicate if the current x,y requires a label 
         --an interger to signel the value of lowest neighbour -- this is only populated when a check is done that it doesnt require a label
         -- a tuple in case both of it's neighbours or not back ground or outofbound, this is my way to populate the equivelncy list
generateLabel :: [[Int]] ->(Int,Int) -> Int->[(Int,Int)] -> (Bool, Int, [(Int,Int)])
generateLabel matrix (x,y) backgorund  eList  | checkIfValid left backgorund && checkIfValid up backgorund = (False, minimum [left,up], (left, up): eList) --check if it has two valid neighbours
                                              | checkIfValid left backgorund = (False , left, eList)
                                              | checkIfValid up backgorund = (False , up, eList)
                                              |  otherwise = (True, -1, eList) --in the case that it has no valid neighbours then we know it needs to be assigned to the value of the labe, that's indicated by this boolean
                                                                               -- the boolean is also helpful in first scan and makes it less redudandant to both check here and in first scan for neighbours
                                               where current = getElement2D matrix (x, y)
                                                     [left, up] = findLeftandUp matrix (x,y)

--Input: matrix, a starting postion for the search, an initial value for the label(counter) and an empty equivelncy list
--Output: outputs the results of second scan, (a list (1D array) that contains the final values of labeling for each component)
firstScan:: [[Int]] -> (Int,Int) -> Int  -> Int -> [(Int,Int)] ->[Int]
firstScan matrix (x,y) searchNumber label eList         | x > boundaryX = firstScan matrix (0, y+1) searchNumber label eList -- a check to reset the x increment in the recursion and
                                                                                                                             -- calls recrusion with the new y (0,y+1)
                                                        | y > boundaryY =  secondScan (concat matrix) (filter (uncurry (/=)) eList) -- calls second scan after the search has ended, when y
                                                                                                                                    -- value has exceeded it's boundary then it's known that the search is finished
                                                        | current == background = firstScan matrix (x+1, y) searchNumber label eList -- a perfromance enhancing check, to skip the procedure in case that the current element
                                                                                                                                     -- is a background
                                                        | otherwise = let (changeLabel, upOrLeft, eList' ) = generateLabel matrix (x,y) background eList -- explination for the line is found in
                                                                                                                                                         -- the comments of generateLabel function
                                                                          label' = if changeLabel then label+1 else label --if the current location needs labeling the label is incremented

                                                                          matrix' = if changeLabel then setValue (x,y) label matrix --if we need to label current then we update the matrix with val of labele at (x,y)
                                                                                    else setValue (x,y) upOrLeft matrix --else give the minum value of it's neighbours to (x,y)
                                                                      in firstScan matrix' (x+1,y) searchNumber label' eList' -- the recursion call to the new (x,y) -> (x+1,y) with updated input

                                                          where boundaryX = length (head matrix) - 1 --checks for the x boundary could be an input to potentially save computation, however, the computation 
                                                                                                    --isnt that complex and doesnt consume much power relative to current hardware, thus to keep the code nicer
                                                                                                    -- i chose to define it here
                                                                boundaryY = length matrix - 1 -- checks for the y boundary --same perfromance ideolagy as boundaryx
                                                                current = getElement2D matrix (x,y) -- finds the current element (x,y)
                                                                background = 1 - searchNumber -- finds the background

--input: labeled matrix, equivlency list
--Output: the final labeled matrix
secondScan :: [Int] -> [(Int, Int)] -> [Int]
secondScan matrix eList = map replace matrix --maps each element of the matrix to it's equivlent in the equivlency list 
                               where
                                   replace x = fromMaybe x (findTup (cleanElist  eList) x)

--is the main function to find connected compoenents, it recivies a binary matrix for row size r and column size c and a a traget int
--returns the count of each target int in it's largest connected compoenent by calling count on the scan results
nlcc :: [[Int]] -> Int -> Int
nlcc [] searchNumber = 0 -- in case the matrix was empty
nlcc matrix searchNumber | searchNumber `notElem` concat matrix = 0 --saves time and imporves perofrmance, in the case that the target int is not containted in the matrix 
                                                                    --for example nlcc [[0,0,0]] 1 would return 0 with no further computation
                         | otherwise = count (firstScan matrix (0,0) searchNumber 2 [(0,0)]) -- calls firstscan to init the componenet labeling process
                                                                                             