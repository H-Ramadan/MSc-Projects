This readme file is to explain how to run the code to get the statistics used to complement the descriptive analysis of the dataset.
Note the same applies to the implentation and training

The python code was executed on Google's Colab platform.

The code runs based on the fact that the data set files are present in the same directory as the code file.

So before running the code make sure to copy the files to the directory that the python code file is in.